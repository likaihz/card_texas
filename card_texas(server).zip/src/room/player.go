package room

import (
	"../card"
	"../lib/xx"
	"../lib/xxio"
	"fmt"
	"strconv"
	"sync"
)

// class Player
type Player struct {
	sync.Mutex
	ready         bool
	idx           int
	uid, name     string
	cli           chan string
	cards         *card.Cards
	chips, stakes int

	fold bool
}

func NewPlayer(idx int, uid string, cli chan string) *Player {
	p := &Player{idx: idx, uid: uid}
	p.cli = cli
	name, err := getname(uid)
	if err != nil {
		return nil
	}
	p.name = name
	p.fold = false
	p.Init()
	return p
}

func (p *Player) Init() {
	p.cards = card.NewCards()
	p.stakes = 0
}

// interface of info
func (p *Player) Is(uid string) bool {
	if p == nil {
		return false
	}
	return p.uid == uid
}

func (p *Player) Uid() string {
	return p.uid
}

func (p *Player) Ready() bool {
	if p == nil {
		return false
	}
	return p.ready
}

func (p *Player) SetReady(b bool) {
	p.ready = b
}

func (p *Player) Idx() int {
	return p.idx
}

func (p *Player) Rank() int {
	return p.cards.Rank()
}

func (p *Player) Fold() bool {
	return p.fold
}

func (p *Player) Reset() {
	p.chips = 0
	p.fold = false
}
func (p *Player) Chips() int {
	return p.chips
}

func (p *Player) Stakes() int {
	return p.stakes
}

func (p *Player) Addstakes(s int) int {
	p.stakes += s
	return p.stakes
}

func (p *Player) All_in() int {
	c := p.chips
	p.chips -= c
	p.stakes += c
	return c
}

func (p *Player) Cards() *card.Cards {
	return p.cards
}

func (p *Player) Msg() map[string]interface{} {
	msg := map[string]interface{}{}
	msg["name"] = p.name
	msg["rank"] = p.cards.Rank()
	msg["cards"] = p.cards.Msg()
	msg["score"] = p.score
	return msg
}

func (p *Player) Send(msg map[string]interface{}) {
	if p == nil {
		return
	}
	str := xx.Map2str(msg)
	p.cli <- str
}

// interface of action
func (p *Player) Obtain(c *card.Card) {
	p.cards.Insert(c)
}

func (p *Player) Compare(player *Player) int {
	cards := player.Cards()
	return p.cards.Compare(cards)
}

func (p *Player) Win(player *Player) {
	// ...
}

func (p *Player) Sendcard(c *card.Card) {
	msg := map[string]interface{}{}
	msg["opt"] = "card"
	msg["data"] = c.Msg()
	p.Send(msg)
}

func (p *Player) Sendcards() {
	msg := map[string]interface{}{}
	msg["opt"] = "cards"
	msg["data"] = p.cards.Msg()
	p.Send(msg)
}

func (p *Player) Stakeover() int {
	c := p.chips
	p.chips = 0
	return c

}

func (p *Player) Sendpermissions(act ...string) {
	//...
}

// implementation
func getname(uid string) (string, error) {
	cfg, err := xxio.Read("user")
	if err != nil {
		return "", err
	}
	val, ok := cfg[uid]
	if !ok {
		return "", fmt.Errorf("invalid uid!")
	}
	data := val.(map[string]interface{})
	name := data["name"].(string)
	return name, nil
}

// test
func (p *Player) Print() {
	s := "player "
	if p == nil {
		s += "none"
	} else {
		idx := strconv.Itoa(p.idx)
		s += idx + " : "
		s += p.name
	}
	fmt.Println(s)
}
